import java.util.*
import entities.Menu

fun main(args: Array<String>) {

    val menu = Menu()
    menu.mostrarMenu()
}


