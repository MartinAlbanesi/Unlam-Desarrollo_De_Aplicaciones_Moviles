package com.practice.tallerdereparacion.entities

data class SparePart (val code : Int, val name : String, val price : Double, val unitsInStock : Int){

}