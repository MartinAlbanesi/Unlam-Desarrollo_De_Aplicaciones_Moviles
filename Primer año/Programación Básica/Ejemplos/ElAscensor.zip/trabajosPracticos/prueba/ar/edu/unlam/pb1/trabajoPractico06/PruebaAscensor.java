package ar.edu.unlam.pb1.trabajoPractico06;

import java.util.Scanner;

import ar.edu.unlam.pb1.trabajoPractico02.Persona;

public class PruebaAscensor {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		Ascensor ascensorActual;
		int pisoMinimo =0, pisoMaximo = 0, opcionDeseada = 0;
		double pesoMaximo = 0.0;
		
		System.out.println("Estamos instalando el ascensor");
		System.out.println("Ingrese el piso minimo que va a tener");
		pisoMinimo = teclado.nextInt();
		System.out.println("Ingrese el piso m�ximo que va a tener");
		pisoMaximo = teclado.nextInt();
		System.out.println("Ingrese el peso m�ximo que va a tener");
		pesoMaximo = teclado.nextDouble();

		ascensorActual = new Ascensor(pisoMinimo, pisoMaximo, pesoMaximo);
		
		do {
			mostrarMenuDeOpciones(ascensorActual);
			
			System.out.println("Ingrese la opci�n deseada: ");
			opcionDeseada = teclado.nextInt();
			
			switch(opcionDeseada) {
			case 1:
				abrirPuerta(teclado, ascensorActual);
				break;
			case 2:
				cerrarPuerta(teclado, ascensorActual);
				break;
			case 3:
				ingresar(teclado, ascensorActual);
				break;
			case 4:
				subir(teclado, ascensorActual);
				break;
			case 5:
				bajar(teclado, ascensorActual);
				break;
			case 6:
				salir(teclado, ascensorActual);
				break;
			case 7:
				irAlPiso(teclado, ascensorActual);
				break;
			case 9:
				break;
			default:
				System.out.println("Funcionalidad en contrucci�n");
			}
		}while(opcionDeseada!=9);

	}
	
	private static void mostrarMenuDeOpciones(Ascensor actual) {
		System.out.println();
		System.out.println("Panel de control");
		System.out.println(actual);
		System.out.println("1 - Abrir la puerta");
		System.out.println("2 - Cerrar la puerta");
		System.out.println("3 - Ingresar");
		System.out.println("4 - Subir");
		System.out.println("5 - Bajar");
		System.out.println("6 - Salir");
		System.out.println("7 - Ir al piso");
		System.out.println("9 - Finalizar");
		System.out.println();
	}

	private static void abrirPuerta(Scanner teclado, Ascensor ascensorActual) {
		ascensorActual.abrirPuerta();
		if(ascensorActual.isPuertaAbierta()) {
			System.out.println("Se abri� la puerta");
		}
		else {
			System.out.println("La puerta no se pudo abrir");
		}
	}

	private static void cerrarPuerta(Scanner teclado, Ascensor ascensorActual) {
		ascensorActual.cerrarPuerta();
		if(!ascensorActual.isPuertaAbierta()) {
			System.out.println("Se cerr� la puerta");
		}
		else {
			System.out.println("La puerta no pudo cerrarse. Sobrepeso!");
		}
	}

	private static void ingresar(Scanner teclado, Ascensor ascensorActual) {
		double pesoAIngresar = 0.0;
		if(ascensorActual.isPuertaAbierta()) {
			System.out.println("Pesando la carga. Ingrese el peso");
			pesoAIngresar = teclado.nextDouble();
			ascensorActual.ingresar(pesoAIngresar);
			if(ascensorActual.isSobrecarga()) {
				System.out.println("Sobrecarga!");
			}
		}
		else {
			System.out.println("Primero tiene que abrir la pruerta");
		}
	}
	
	private static void salir(Scanner teclado, Ascensor ascensorActual) {
		double pesoABajar = 0.0;
		if(ascensorActual.isPuertaAbierta()) {
			System.out.println("Pesando la carga que baja. Ingrese el peso");
			pesoABajar = teclado.nextDouble();
			ascensorActual.salir(pesoABajar);
		}
		else {
			System.out.println("Primero tiene que abrir la pruerta");
		}
	}

	private static void bajar(Scanner teclado, Ascensor ascensorActual) {
		if(ascensorActual.bajar()) {
			System.out.println("Bajando");
		}
		else {
			System.out.println("No es para que se asuste, pero no se est� pudiendo bajar!");
		}
		
	}

	private static void subir(Scanner teclado, Ascensor ascensorActual) {
		if(ascensorActual.subir()) {
			System.out.println("Subiendo");
		}
		else {
			System.out.println("No es para que se asuste, pero no se puede subir!");
		}
		
	}
	
	private static void irAlPiso(Scanner teclado, Ascensor ascensorActual) {
		int pisoDeseado = 0;
		System.out.println("Ingrese el piso al que desea dirigirse");
		pisoDeseado = teclado.nextInt();
		
		if(pisoDeseado>=ascensorActual.getPISO_MINIMO() && pisoDeseado<=ascensorActual.getPISO_MAXIMO()) {
			if(pisoDeseado>ascensorActual.getPisoActual()) {
				System.out.println("Subiendo");
			}
			else {
				System.out.println("Bajando");
			}
			if(ascensorActual.irAlPiso(pisoDeseado)) {
				System.out.println("Usted ha llegado al piso " + ascensorActual.getPisoActual());
			}
			else {
				System.out.println("Algo salio mal. Estamos en el piso" + ascensorActual.getPisoActual());
			}
		}
		else {
			System.out.println("No es posible ir al piso ingresado");
		}
	}
}
