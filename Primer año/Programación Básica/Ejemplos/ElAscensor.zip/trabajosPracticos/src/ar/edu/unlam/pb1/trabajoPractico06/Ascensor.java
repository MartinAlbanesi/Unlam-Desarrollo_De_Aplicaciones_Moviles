package ar.edu.unlam.pb1.trabajoPractico06;

import ar.edu.unlam.pb1.trabajoPractico02.Persona;

public class Ascensor {
	
	private final int PISO_MINIMO;
	private final int PISO_MAXIMO;
	private final double PESO_MAXIMO;
	private final int PLANTA_BAJA = 0;
	private double pesoActual;
	private int pisoActual;
	private boolean puertaAbierta;
	private boolean sobrecarga;
	// private int capacidadActual; 
	// private Persona ocupantes[];
	private boolean enMovimiento;
	
	public Ascensor(int pisoMaximo, double pesoMaximo) {
		this.PISO_MINIMO = PLANTA_BAJA;
		this.PISO_MAXIMO = pisoMaximo;
		this.PESO_MAXIMO = pesoMaximo;
		this.pesoActual = 0;
		this.pisoActual = PISO_MINIMO;
		this.puertaAbierta = false;
		this.sobrecarga = false;
		this.enMovimiento = false;
	}
	
	public Ascensor(int pisoMinimo, int pisoMaximo, double pesoMaximo) {
		this.PISO_MINIMO = pisoMinimo;
		this.PISO_MAXIMO = pisoMaximo;
		this.PESO_MAXIMO = pesoMaximo;
		this.pesoActual = 0.0;
		this.pisoActual = PISO_MINIMO;
		this.puertaAbierta = false;
		this.sobrecarga = false;
		this.enMovimiento = false;
	}
	
/*	public void ingresar(Persona elQueSube) {
		this.pesoActual+=elQueSube.pesar();
	}*/

	public void ingresar(double pesoDeLaPersonaUObjetoQueIngresa) {
		this.pesoActual+=pesoDeLaPersonaUObjetoQueIngresa;
		this.evaluarSobrecarga();
	}

	private void evaluarSobrecarga() {
		if(this.pesoActual>this.PESO_MAXIMO) {
			sobrecarga = true;
		}
		else {
			sobrecarga = false;
		}
	}

	public boolean subir() {
		boolean sePudoSubir = false;
		//if(puertaAbierta==false) {
		//if(puertaAbierta!=true) {
		if(!puertaAbierta && pisoActual<PISO_MAXIMO) {
			pisoActual++;
			sePudoSubir = true;
		}
		return sePudoSubir;
	}
	
	public boolean bajar() {
		boolean sePudoBajar = false;
		if(!puertaAbierta && pisoActual>PISO_MINIMO) {
			pisoActual--;
			sePudoBajar = true;
		}
		return sePudoBajar;
	}
	
	public boolean abrirPuerta() {
		if(!enMovimiento) {
			this.puertaAbierta = true;
			return true;
		}
		return false;
	}
	
	public boolean cerrarPuerta() {
		boolean sePudoCerrar = false;
		if(!sobrecarga) {
			this.puertaAbierta = false;
			sePudoCerrar = true;
		}
		return sePudoCerrar;
	}
	
	public void salir(double pesoQueSePierde) {
		if(pesoQueSePierde<=this.pesoActual) {
			pesoActual-=pesoQueSePierde;
		}
		evaluarSobrecarga();
	}

	public int getPISO_MINIMO() {
		return PISO_MINIMO;
	}

	public int getPISO_MAXIMO() {
		return PISO_MAXIMO;
	}

	public double getPESO_MAXIMO() {
		return PESO_MAXIMO;
	}

	public double getPesoActual() {
		return pesoActual;
	}

	public int getPisoActual() {
		return pisoActual;
	}

	public boolean isPuertaAbierta() {
		return puertaAbierta;
	}

	public boolean isSobrecarga() {
		return sobrecarga;
	}
	
	public boolean irAlPiso(int pisoDeseado) {

		this.enMovimiento = true;
		while(pisoDeseado > this.pisoActual && pisoDeseado <= PISO_MAXIMO && !puertaAbierta) {
			this.subir();
		}
		while(pisoDeseado < this.pisoActual && pisoDeseado >= PISO_MINIMO && !puertaAbierta) {
			this.bajar();
		}
		this.enMovimiento = false;
		
		if(this.pisoActual == pisoDeseado) {
			return true;
		}
		else {
			return false;
		}
		
	}
	
	public String toString() {
		String resultado = "";

		resultado = "Piso actual: " + this.pisoActual + ". Peso actual: " + this.pesoActual ;
		if(puertaAbierta) {
			resultado += " puerta abierta";
		}
		else {
			resultado += " puerta cerrada";
		}
		return resultado;
	}
}
