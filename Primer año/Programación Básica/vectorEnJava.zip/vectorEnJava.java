import java.util.Scanner;

public class VectorCargadoDeTeclado {

	public static void main(String[] args) {
		final int TOPE = 10;
	     int i=0;
	     	// declara un vector de tipo primitivo enteros.
	      int[] vectorEstatico;
	      // El tamaño del vector va a ser de 5 
		     vectorEstatico = new int[TOPE];
	  //El constructor crea el vector y lo inicializa (lo limpia)
	     Scanner teclado = new Scanner(System.in);
	     System.out.println("CARGA DEL VECTOR:");
	     for ( i = 0; i < TOPE; i++) {
	    	 System.out.println("Se ingresa el elemento:"+ i +"del vector"); 
	    	 vectorEstatico[i]=teclado.nextInt();
	     }
	     //Mostramos los elemento almacendados en el vector
	     for ( i = 0; i < TOPE; i++) {
	    	 System.out.println("en el indice:"+ i +" se almaceno el valor: "+ vectorEstatico[i]);
	     }
	teclado.close();
	}

}