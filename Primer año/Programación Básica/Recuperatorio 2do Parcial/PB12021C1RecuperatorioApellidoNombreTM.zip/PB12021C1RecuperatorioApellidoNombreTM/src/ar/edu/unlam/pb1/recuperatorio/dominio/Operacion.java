package ar.edu.unlam.pb1.recuperatorio.dominio;

public enum Operacion {
	Compra,
	Venta
}
