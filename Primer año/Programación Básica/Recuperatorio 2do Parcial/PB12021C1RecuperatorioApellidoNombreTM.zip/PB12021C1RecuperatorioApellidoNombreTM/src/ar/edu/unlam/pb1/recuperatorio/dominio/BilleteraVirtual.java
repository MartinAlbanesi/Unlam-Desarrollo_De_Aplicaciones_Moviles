package ar.edu.unlam.pb1.recuperatorio.dominio;

public class BilleteraVirtual {
	
	private double TIPO_DE_CAMBIO_ETHEREUM = 1859.00;
	private int CANTIDAD_DE_CRIPTOMONEDAS_EN_TRANSACCION = 100000;

	private Transaccion transacciones[];
	
	/*
	 * Constructor. Se deben generar los atributos necesarios para el correcto funcionamiento.
	 */
	public BilleteraVirtual(String nombreBilletera) {
		
	}
	
	/**
	 * Compra o vende una criptomoneda debiendo indicarse la cantidad. Agrega la transaccion al array de transacciones.
	 * @param cantidad int		Cantidad de criptomoneda a comprar
	 * @return Verdadero en caso de éxito
	 * */
	public boolean comprarVenderCriptomoneda(int cantidad) {
		return false;
	}
	

	/**
	 * Obtiene el saldo actual calculado en base a las transacciones realizadas
	 * @return Saldo actual o cero
	 * */
	public double obtenerSaldoActual() {
		// TODO: Redondear el resultado para ver solo 2 decimales.
		return 0L;
	}
	
	/**
	 * Obtiene la transaccion realizada de mayor monto
	 * @return Transaccion		Transaccion de mayor monto o null
	 * */
	public Transaccion obtenerTransaccionMayorMonto() {
		return null;
	}
	
	/**
	 * Obtiene las transacciones realizadas ordenadas descendientemente
	 * @return Transaccion[]	Array de transacciones ordenadas
	 * */
	public Transaccion[] listrarTransaccionesDescendientemente() {
		return null;
	}
}
