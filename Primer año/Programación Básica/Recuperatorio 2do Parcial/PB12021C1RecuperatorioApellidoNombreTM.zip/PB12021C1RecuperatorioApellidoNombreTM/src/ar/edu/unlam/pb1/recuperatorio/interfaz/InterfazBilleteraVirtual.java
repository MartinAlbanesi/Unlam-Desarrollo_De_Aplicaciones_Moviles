package ar.edu.unlam.pb1.recuperatorio.interfaz;

import java.util.Scanner;

import ar.edu.unlam.pb1.recuperatorio.dominio.BilleteraVirtual;

public class InterfazBilleteraVirtual {

	public static void main(String[] args) {
		
		System.out.println("Bienvenido a la billetera Bin Ance.");
		
		int opcion = 0;
		do {
			opcion = seleccionarOpcion();
			switch (opcion) {
			case 1:
				break;
			case 2: 
				// TODO: Si no esta autenticado, no puede realizar las siguiente operaciones. Se debe mostrar el nombre y apellido
				break;
			case 3:
				// TODO: Mostrar mensaje en caso de exito o error
				break;
			case 4:
				// TODO: Mostrar mensaje en caso de exito o error
				break;
			case 5:
				break;
			case 6:
				break;
			case 7:
				break;
			case 9:
				// TODO: Se debe cerrar la sesión del operador
				break;
			default:
				System.out.println("Opcion Invalida");
				break;
			}

		} while (opcion != 9);
		
		System.out.println("Hasta pronto!");
	}
	
	private static int seleccionarOpcion() {
		Scanner teclado = new Scanner(System.in);
		int opcionSeleccionada=0;
		
		System.out.println("************************");
		System.out.println("Menu de Transacciones Virtuales\n");
		System.out.println("1 - Dar de alta un Operador ");
		System.out.println("2 - Iniciar sesion"); 
		System.out.println("3 - Comprar criptomoneda"); 
		System.out.println("4 - Vender criptomoneda");
		System.out.println("5 - Informar el saldo de criptomonedas");
		System.out.println("6 - Informar la transaccion de criptomonedas de mayor monto");
		System.out.println("7 - Listar las transacciones de criptomonedas ordenadas descendientemente");
		System.out.println("9 - Salir");
		System.out.println("************************");
		System.out.println("Ingrese una opcion");
		
		opcionSeleccionada = teclado.nextInt();
		
		return opcionSeleccionada;
	}
}
