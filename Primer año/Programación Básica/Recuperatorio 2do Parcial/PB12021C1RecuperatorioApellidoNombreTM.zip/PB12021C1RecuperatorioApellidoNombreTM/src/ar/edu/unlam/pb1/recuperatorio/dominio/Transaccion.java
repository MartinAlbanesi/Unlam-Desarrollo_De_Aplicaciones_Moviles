package ar.edu.unlam.pb1.recuperatorio.dominio;

public class Transaccion {
	
	/*
	 * Constructor. Se deben generar los atributos necesarios para el correcto funcionamiento.
	 */
	public Transaccion(Operacion operacion, int cantidad, double valor) {
	}
}
