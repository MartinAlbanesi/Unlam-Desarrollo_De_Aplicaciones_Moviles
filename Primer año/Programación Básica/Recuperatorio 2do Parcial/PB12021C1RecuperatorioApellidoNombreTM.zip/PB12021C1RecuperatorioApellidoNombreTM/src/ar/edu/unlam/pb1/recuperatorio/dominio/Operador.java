package ar.edu.unlam.pb1.recuperatorio.dominio;

public class Operador {
	
	/*
	 * Constructor. Se deben generar los atributos necesarios para el correcto funcionamiento.
	 */
	public Operador (String nombre, String apellido, String nickName, String contrasenia, boolean habilitadoParaRealizarTransacciones) {
		
	}
	
	/**
	 * Realiza la validación del nick y la contraseña para iniciar sesión
	 * @param nickName String		Nombre de usuario
	 * @param contrasenia String	Contraseña del usuario
	 * @return Verdadero en caso de exito
	 * */
	public boolean iniciarSesion(String nickName, String contrasenia) {
		return false;
	}
	
	/**
	 * Cierra la sesión del operador
	 * @return boolean		Verdadero en caso de exito
	 * */
	public boolean cerrarSesion() {
		return false;
	}

	/**
	 * Verifica si el usuario tiene la sesión iniciada
	 * @return boolean		Verdadero en caso de estar autenticado
	 * */
	public boolean estaAutenticado() {
		return false;
	}
}
