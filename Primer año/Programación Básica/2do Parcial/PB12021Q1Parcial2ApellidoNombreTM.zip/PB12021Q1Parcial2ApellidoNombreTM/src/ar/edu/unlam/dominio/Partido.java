package ar.edu.unlam.dominio;

public class Partido {

	
	private int numeroPartido;
	private boolean iniciado;
	private Jugador[] equipoLocal;
	private Jugador[] equipoVisitante;
	private Jugador[] goles;
    
	public Partido(int numeroPartido) {
		this.numeroPartido = numeroPartido;
	}

	/**
	 * Agregar un jugador al array del equipo correspondiente según el tipo de equipo
	 * 
	 * @param jugador 	Jugador Jugador que se agregará al equipo correspondiente
	 * @return boolean 	Verdadero en caso de éxito
	 */
	public boolean agregarJugadorAEquipo(Jugador jugador, TipoEquipo tipoEquipo) {
		return false;
	}

	/**
	 * Agrega un jugador al array de goles
	 * 
	 * @param jugador 	Jugador Jugador que se agregará al array de goles
	 * @return boolean 	Verdadero en caso de éxito
	 */
	public boolean registrarGolDeJugador(Jugador jugador) {
		return false;
	}

	/**
	 * Busca un jugador por su DNI, debiendo indicar el equipo al que pertenece
	 * @param dni int					DNI del jugador
	 * @param tipoEquipo TipoEquipo		Tipo de equipo en el que se buscará el jugador (local o visitante)
	 * @return Jugador 					En caso de encontrarlo o null.
	 * */
	public Jugador buscarJugadorPorDNIEnEquipo(int dni, TipoEquipo tipoEquipo) {
		return null;
	}

	/**
	 * Cambia el estado de la variable iniciado a verdadero
	 * */
	public void iniciarPartido() {

	}

	/**
	 * Cambia el estado de la variable iniciado a falso
	 * */
	public void finalizarPartido() {

	}

	/**
	 * Obtiene un array de jugadores que marcaron un gol, debiendo ser ordenados por DNI
	 * @return Jugador[]	En caso de existir goles o null.
	 * */
	public Jugador[] obtenerGolesDeJugadoresOrdenadosPorDni() {
		return null;
	}

	/**
	 * Devuelve un String con la descripción del equipo ganador: Local, Visitante o Empate
	 */
	public String obtenerEquipoGanador() {
		return "";
	}
	
	/*
	 * Devuelve el jugador mas joven querealizo un gol
	 */
	public Jugador obtenerJugadorMasJovenQueHizoUnGol() {
		
		return null;
	}
}
