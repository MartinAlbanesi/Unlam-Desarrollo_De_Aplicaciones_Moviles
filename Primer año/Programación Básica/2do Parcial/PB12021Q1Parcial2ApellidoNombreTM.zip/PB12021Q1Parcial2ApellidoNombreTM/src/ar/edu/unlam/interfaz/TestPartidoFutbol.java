package ar.edu.unlam.interfaz;

public class TestPartidoFutbol {

	public static void main(String[] args) {
		/*
		 * TODO: Generar un menu que permita:
		 * 
		 * 1) Crear partido: Se debera solicitar el ingreso de datos por pantalla.
		 * 2) Agregar jugador equipo local: Se debera� solicitar el ingreso de datos por pantalla.
		 * 3) Agregar jugador equipo visitante: Se deberá solicitar el ingreso de datos por pantalla.
		 * 4) Iniciar el partido: Cambia el estado de la variable iniciado de la clase Partido 
		 *                        No se puede inciar el partido si ambos equipos no tienen almenos 11 jugadores cada uno.
		 * 
		 * 5) Registar gol: Para registrar un gol, primero debe buscarse el jugador por su DNI, indicando su equipo (Local o Visitante). Debe existir el partido y estar iniciado.
		 * 6) Finalizar partido: Cambia el estado de la variable iniciado de la clase Partido.
		 * 
		 * */

		/*************************************************************
		 * 
		 * Notas:
		 *  - El menú finaliza, cuando el partido esté finalizado.
		 *	- Una vez finalizado el partido, informar equipo ganador indicando: Local, Visitante o Empate y jugadores que marcaron gol ordenados por DNI (en caso de existir).
		 *  - y tambien informar el jugador mas joven que hizo un gol   
		 *  
		 *  Puede crear todos los metodos y atributos que necesite 
		 *************************************************************/
	}

}
