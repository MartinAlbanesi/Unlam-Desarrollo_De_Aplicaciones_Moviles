package ar.edu.unlam.dominio;

public class Jugador {

	private int dni;
	private String nombre;
	private String apellido;
	private int numeroCamiseta;
	private int edad;
	private TipoEquipo tipoEquipo;
	private Puesto puesto;
	public Jugador(int dni, String nombre, String apellido, int numeroCamiseta, int edad, TipoEquipo tipoEquipo,
			Puesto puesto) {
		
	}
	
	

}
