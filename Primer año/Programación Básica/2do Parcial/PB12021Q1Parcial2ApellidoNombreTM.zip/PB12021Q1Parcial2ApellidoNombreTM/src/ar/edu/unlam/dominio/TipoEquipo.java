package ar.edu.unlam.dominio;

public enum TipoEquipo {
	Local, Visitante
}
