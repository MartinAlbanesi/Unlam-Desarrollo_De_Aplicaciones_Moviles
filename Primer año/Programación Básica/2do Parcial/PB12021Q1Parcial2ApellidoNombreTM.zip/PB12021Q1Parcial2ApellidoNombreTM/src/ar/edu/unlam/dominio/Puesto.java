package ar.edu.unlam.dominio;

public enum Puesto {
	Arquero, Defensor, Mediocampista, Delantero
}
