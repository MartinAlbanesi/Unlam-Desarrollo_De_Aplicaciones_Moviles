package ar.edu.unlam.interfaz;

import java.util.Scanner;

import ar.edu.unlam.dominio.Partido;
import ar.edu.unlam.dominio.TipoEquipo;
import ar.edu.unlam.dominio.Jugador;

public class TestPartidoFutbol {

	public static void main(String[] args) {
		/*
		 * TODO: Generar un menu que permita:
		 * 
		 * 1) Crear partido: Se debera solicitar el ingreso de datos por pantalla.
		 * 2) Agregar jugador equipo local: Se debera� solicitar el ingreso de datos por pantalla.
		 * 3) Agregar jugador equipo visitante: Se deberá solicitar el ingreso de datos por pantalla.
		 * 4) Iniciar el partido: Cambia el estado de la variable iniciado de la clase Partido 
		 *                        No se puede inciar el partido si ambos equipos no tienen almenos 11 jugadores cada uno.
		 * 
		 * 5) Registar gol: Para registrar un gol, primero debe buscarse el jugador por su DNI, indicando su equipo (Local o Visitante). Debe existir el partido y estar iniciado.
		 * 6) Finalizar partido: Cambia el estado de la variable iniciado de la clase Partido.
		 * 
		 * */

		/*************************************************************
		 * 
		 * Notas:
		 *  - El menú finaliza, cuando el partido esté finalizado.
		 *	- Una vez finalizado el partido, informar equipo ganador indicando: Local, Visitante o Empate y jugadores que marcaron gol ordenados por DNI (en caso de existir).
		 *  - y tambien informar el jugador mas joven que hizo un gol   
		 *  
		 *  Puede crear todos los metodos y atributos que necesite 
		 *************************************************************/
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Bienvenido ");
		System.out.println("Ingresar el numero de partido: ");
		int nroPartido = teclado.nextInt();
		Partido partido = new Partido(nroPartido);
		
		System.out.println("Desea ingresar jugador a equipo local o visitante? (L - V): ");
		char opcion = teclado.next().charAt(0);

		switch(opcion) {
		case 'l':
		case 'L':
			System.out.println("A continuacion ingrese los datos del jugador Local: ");
			System.out.println("Ingresar el dni del jugador: ");
			int dniLocal = teclado.nextInt();
			System.out.println("Ingresar el nombre del jugador: ");
			String nombreLocal = teclado.nextLine();
			System.out.println("Ingresar el nombre del jugador: ");
			String apellidoLocal = teclado.nextLine();
			System.out.println("Ingresar el nro del jugador: ");
			int nroLocal = teclado.nextInt();
			System.out.println("Ingresar el edad del jugador: ");
			int edadLocal = teclado.nextInt();
			System.out.println("Ingresar el equipo del jugador: ");
			String equipoLocal = teclado.nextLine();
			System.out.println("Ingresar el equipo del jugador: ");
			String puestoLocal = teclado.nextLine();
			partido.agregarJugadorAEquipo(new Jugador(dniLocal, nombreLocal, apellidoLocal, nroLocal, edadLocal, nroLocal, edadLocal,equipoLocal,puestoLocal), TipoEquipo.Local);
			break;
		case 'v':
		case 'V':
			System.out.println("Agregar jugador de equipo local: ");
			partido.agregarJugadorAEquipo(new Jugador(teclado), TipoEquipo.Visitante);
			break;
		default:
			System.out.println("No se ha seleccionado ningun tipo de equipo");
		}
		
		if (partido != null) {
			if (partido.isIniciado()) {
				
			}
		}
	
		
	
	}
}



