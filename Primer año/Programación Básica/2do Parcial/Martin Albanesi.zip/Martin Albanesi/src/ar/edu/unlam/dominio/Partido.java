package ar.edu.unlam.dominio;

public class Partido {

	
	private int numeroPartido;
	private boolean iniciado;
	private Jugador[] equipoLocal;
	private Jugador[] equipoVisitante;
	private Jugador[] goles;
    
	public Partido(int numeroPartido) {
		this.numeroPartido = numeroPartido;
	}

	/**
	 * Agregar un jugador al array del equipo correspondiente según el tipo de equipo
	 * 
	 * @param jugador 	Jugador Jugador que se agregará al equipo correspondiente
	 * @return boolean 	Verdadero en caso de éxito
	 */
	public boolean agregarJugadorAEquipo(Jugador jugador, TipoEquipo tipoEquipo) {
		boolean exito = false;
	    switch (tipoEquipo) {
	        case Local:
	            for(int i=0 ; i < this.equipoLocal.length ; i++) {
	            	if(this.equipoLocal[i] == null) {
	            		equipoLocal[i] = jugador;
	            		exito = true;
	            		break;
	            	}
	            }
	            break;
	        case Visitante:
	        	for(int i=0 ; i < this.equipoVisitante.length ; i++) {
	            	if(this.equipoVisitante[i] == null) {
	            		equipoVisitante[i] = jugador;
	            		exito = true;
	            		break;
	            	}
	            break;
	        	}
	        default:
	        	exito = false;
	    }
	    
		return exito;
		
	}

	/**
	 * Agrega un jugador al array de goles
	 * 
	 * @param jugador 	Jugador Jugador que se agregará al array de goles
	 * @return boolean 	Verdadero en caso de éxito
	 */
	public boolean registrarGolDeJugador(Jugador jugador) {
		boolean jugadorAgregado = false;
		for(int i=0; i < this.goles.length ; i++) {
			if (this.goles[i] == null) {
				goles[i] = jugador;
				jugadorAgregado = true;
				break;
			}
			else {
				jugadorAgregado = false;
			}
		}
		return jugadorAgregado;
	}

	/**
	 * Busca un jugador por su DNI, debiendo indicar el equipo al que pertenece
	 * @param dni int					DNI del jugador
	 * @param tipoEquipo TipoEquipo		Tipo de equipo en el que se buscará el jugador (local o visitante)
	 * @return Jugador 					En caso de encontrarlo o null.
	 * */
	public Jugador buscarJugadorPorDNIEnEquipo(int dni, TipoEquipo tipoEquipo) {
		
		switch(tipoEquipo) {
		case Local:
			for(int i=0 ; i < this.equipoLocal.length ; i++) {
            	if(this.equipoLocal[i].getDni() == dni) {
            		return this.equipoLocal[i];
            	}
            }
		case Visitante:
        	for(int i=0 ; i < this.equipoVisitante.length ; i++) {
            	if(this.equipoVisitante[i].getDni() == dni) {
            		return this.equipoVisitante[i];
            	}
        	}
        default:
        	return null;
		}
		
	}

	/**
	 * Cambia el estado de la variable iniciado a verdadero
	 * */
	public void iniciarPartido() {
		this.iniciado = true;
	}

	/**
	 * Cambia el estado de la variable iniciado a falso
	 * */
	public void finalizarPartido() {
		this.iniciado = false;
	}

	/**
	 * Obtiene un array de jugadores que marcaron un gol, debiendo ser ordenados por DNI
	 * @return Jugador[]	En caso de existir goles o null.
	 * */
	public Jugador[] obtenerGolesDeJugadoresOrdenadosPorDni() {
		for(int i=0; i < this.goles.length ; i++) {
			if(this.goles[i].getDni() > this.goles[i+1].getDni()) {
				int aux = this.goles[i].getDni();
				this.goles[i].setDni(this.goles[i+1].getDni());
				this.goles[i+1].setDni(aux);
			}
		}
		return this.goles;
	}

	/**
	 * Devuelve un String con la descripción del equipo ganador: Local, Visitante o Empate
	 */
	public String obtenerEquipoGanador() {
		int totalGolesLocal=0;
		int totalGolesVisitante=0;
		for(int i=0 ; i < this.goles.length ; i++) {
			if(this.goles[i] != null) {
				switch (this.goles[i].getTipoEquipo()) {
				case Local:
					totalGolesLocal++;
					break;
				case Visitante:
					totalGolesVisitante++;
					break;
				default:
					break;
				}
			}
		}
		if(totalGolesLocal > totalGolesVisitante) {
			return "Local";
		}
		else if (totalGolesLocal < totalGolesVisitante){
			return "Visitante";
		}
		else if (totalGolesLocal == totalGolesVisitante) {
			return "Empate";
		}
		return null;
	}
	

//				if(this.goles[i].getTipoEquipo() == ''Local) {
//					totalGolesLocal++;
//				}
//				else if (this.goles[i].getTipoEquipo() == Visitante) {
//					totalGolesVisitante;
//				}
//			}
	
	/*
	 * Devuelve el jugador mas joven querealizo un gol
	 */
	public Jugador obtenerJugadorMasJovenQueHizoUnGol() {
		Jugador masJoven = null;
		for(int i=0 ; i < this.goles.length ; i++) {
			if(this.goles[i].getEdad() < this.goles[i+1].getEdad()) {
				masJoven = this.goles[i];
			}
		}
		return masJoven;
	}

	public boolean isIniciado() {
		return iniciado;
	}
	
	
}
