package ar.edu.unlam.pb2.cuentasbancarias;

public enum TipoTransaccion {
	DEPOSITO, EXTRACCION, TRANSFERENCIA;
}
