package ar.edu.unlam.pb2.cuentasbancarias;

public class CuentaDeAhorro extends Cuenta {

	private Double reserva = 0.0;

	public CuentaDeAhorro(Double reserva) {
		/*
		 * Se invoca explicitamente el contructor del padre porque no tiene un
		 * contructor vac�o.
		 */
		super(0.0);
		this.reserva = reserva;
	}

	public void reservar(Double monto) {
		this.reserva = monto;
		this.saldo = this.saldo - monto;
	}

	public Double getSaldo() {
		return this.saldo;
	}

	/*
	 * Cuando deseo invocar el comportamiento del m�todo sobreescrito.
	 */
	@Override
	public void depositar(Double monto) {
		this.saldo = this.saldo + monto;

	}

}
