package ar.edu.umla.pb2.pacial;

public class EmpleadoPlantaTemporaria extends Empleado {
	@Override
	public Double getValorHora() {
		return 200.00;
	}
}
