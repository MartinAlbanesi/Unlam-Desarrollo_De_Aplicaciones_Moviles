package Figuras;

public class Rectangulo extends Figura {

	private Punto EsquinaSupDer;

	/*
	 * pPunto es el punto de la esquina inferior derecha lmayor es el lado mayor
	 * lmenor es el lado menor
	 */
	public Rectangulo(Punto pPunto, double lMayor, double lMenor) {
		super(pPunto, lMayor, lMenor);
		calcularEsqSupDer();
	}

	private void calcularEsqSupDer() {
		double ejeX = getPosicion().getEjeX() + getLadoMayor();
		double ejeY = getPosicion().getEjeY() + getLadoMenor();
		Punto punto = new Punto(ejeX, ejeY);

		this.EsquinaSupDer = punto;
	}

	/*
	 * Area = base * altura
	 */
	@Override
	public double calcularArea() {

		return getLadoMayor() * getLadoMenor();
	}

	public Punto getEsquinaSupDer() {
		return EsquinaSupDer;
	}

	public void setEsquinaSupDer(Punto esquinaSupDer) {
		EsquinaSupDer = esquinaSupDer;
	}

	@Override
	public void setPosicion(Punto pPunto) {
		super.setPosicion(pPunto);
		calcularEsqSupDer();
	}

}
