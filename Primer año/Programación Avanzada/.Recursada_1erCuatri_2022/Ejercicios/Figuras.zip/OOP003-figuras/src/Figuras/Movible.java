package Figuras;

public interface Movible {

	public abstract void mover(double deltaX, double deltaY);

}
