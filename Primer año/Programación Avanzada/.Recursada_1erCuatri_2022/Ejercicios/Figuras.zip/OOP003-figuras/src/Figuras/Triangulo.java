package Figuras;

public class Triangulo {

}
