package Figuras;

public class Elipse extends Figura {

	/*
	 * pPunto es el punto del centro lmayor es el semieje mayor lmenor es el semieje
	 * menor
	 */
	public Elipse(Punto pPunto, double lMenor, double lMayor) {
		super(pPunto, lMenor, lMayor);
	}

	/*
	 * Area = Pi * semiejeMayor * semiejeMenor
	 */
	@Override
	public double calcularArea() {
		return Math.PI * getLadoMayor() * getLadoMenor();
	}

}
