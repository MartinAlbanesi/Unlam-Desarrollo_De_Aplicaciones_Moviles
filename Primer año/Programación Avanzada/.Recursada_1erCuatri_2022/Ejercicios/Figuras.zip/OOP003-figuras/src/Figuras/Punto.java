package Figuras;

public class Punto {
	private double ejeX;
	private double ejeY;
	
	public Punto(double pEjeX, double pEjeY) {
		this.setEjeX(pEjeX);
		this.setEjeY(pEjeY);
	}

	public double getEjeX() {
		return ejeX;
	}

	public void setEjeX(double ejeX) {
		this.ejeX = ejeX;
	}

	public double getEjeY() {
		return ejeY;
	}

	public void setEjeY(double ejeY) {
		this.ejeY = ejeY;
	}
	
}
