package Figuras;

public class Cuadrado extends Rectangulo {
	
	/*
	 * 	pPunto es el punto de la esquina inferior derecha
	 *	lmayor es el lado mayor
	 *	lmenor es el lado menor
	 */
	public Cuadrado(Punto pPunto, double lMayor, double lMenor) {
		super(pPunto, lMayor, lMayor);
		
	}
	
	public Cuadrado(Punto pPunto, double lMayor) {
		super(pPunto, lMayor, lMayor);
		
	}

}
