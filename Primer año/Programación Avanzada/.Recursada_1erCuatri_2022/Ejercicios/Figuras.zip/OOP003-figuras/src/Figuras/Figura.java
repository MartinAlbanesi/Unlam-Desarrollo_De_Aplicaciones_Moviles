package Figuras;

public abstract class Figura implements Comparable<Figura>, Movible {

	private Punto posicion;
	private double ladoMayor;
	private double ladoMenor;

	public Figura(Punto pPunto, double lMayor, double lMenor) {
		this.posicion = pPunto;
		this.ladoMayor = lMayor;
		this.ladoMenor = lMenor;
	}

	public abstract double calcularArea();

	public Punto getPosicion() {
		return posicion;
	}

	public void setPosicion(Punto posicion) {
		this.posicion = posicion;
	}

	public double getLadoMayor() {
		return ladoMayor;
	}

	public void setLadoMayor(double ladoMayor) {
		this.ladoMayor = ladoMayor;
	}

	public double getLadoMenor() {
		return ladoMenor;
	}

	public void setLadoMenor(double ladoMenor) {
		this.ladoMenor = ladoMenor;
	}

	@Override
	public int compareTo(Figura o) {
		int resultado = 0;
		if (this.calcularArea() < o.calcularArea()) {
			resultado = -1;
		} else if (this.calcularArea() > o.calcularArea()) {
			resultado = 1;
		}
		return resultado;
	}

	@Override
	public void mover(double deltaX, double deltaY) {
		Punto nuevoPunto = getPosicion();
		nuevoPunto.setEjeX(nuevoPunto.getEjeX() + deltaX);
		nuevoPunto.setEjeY(nuevoPunto.getEjeY() + deltaY);
		setPosicion(nuevoPunto);
	}

}
