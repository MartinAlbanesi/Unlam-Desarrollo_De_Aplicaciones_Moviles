package Figuras;

public class Circulo extends Elipse {
	
	/*
	 * pPunto es el punto del centro
	 * radio2 puede ser cualquier valor
	 */
	public Circulo(Punto pPunto, double radio, double radio2) {
		super(pPunto, radio, radio);
	}
	
	public Circulo(Punto pPunto, double radio) {
		super(pPunto, radio, radio);
	}

}
