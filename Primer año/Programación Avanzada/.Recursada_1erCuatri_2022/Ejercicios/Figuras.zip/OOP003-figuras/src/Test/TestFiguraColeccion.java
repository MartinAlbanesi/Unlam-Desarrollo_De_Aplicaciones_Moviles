package Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import Figuras.Elipse;
import Figuras.Figura;
import Figuras.Punto;
import Figuras.Rectangulo;

public class TestFiguraColeccion {

	@Test
	public void testColeccionOrdenada() {
		Punto centro = new Punto(1, 1);
		Elipse eli = new Elipse(centro, 2, 1);

		Punto esqInfIzq = new Punto(1, 1);
		Rectangulo rec = new Rectangulo(esqInfIzq, 2, 1);

		List<Figura> lista = new ArrayList<Figura>();

		lista.add(eli);
		lista.add(rec);

		Collections.sort(lista);

		List<Figura> listaEsperada = new ArrayList<Figura>();
		listaEsperada.add(rec);
		listaEsperada.add(eli);

		Assert.assertEquals(listaEsperada, lista);

	}

}
