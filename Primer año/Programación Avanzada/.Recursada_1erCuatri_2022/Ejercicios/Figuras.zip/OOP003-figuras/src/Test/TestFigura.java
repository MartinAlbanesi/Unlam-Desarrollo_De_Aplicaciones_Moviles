package Test;

import org.junit.Assert;
import org.junit.Test;

import Figuras.Circulo;
import Figuras.Cuadrado;
import Figuras.Elipse;
import Figuras.Punto;
import Figuras.Rectangulo;

public class TestFigura {

	@Test
	public void crearUnaElipseEn1_1ConEjeMayor2YEjeMenor1TieneArea6_283() {
		Punto centro = new Punto(1, 1);
		Elipse eli = new Elipse(centro, 2, 1);

		Assert.assertEquals(6.283, eli.calcularArea(), 0.001);
	}

	@Test
	public void mover3_1UnaElipseEn1_1LaLlevaA4_2() {
		Punto centro = new Punto(1, 1);
		Elipse eli = new Elipse(centro, 2, 1);

		eli.mover(3, 1);

		Assert.assertEquals(4, eli.getPosicion().getEjeX(), 0.001);
		Assert.assertEquals(2, eli.getPosicion().getEjeY(), 0.001);
	}

	@Test
	public void crearUnRectanguloEn1_1ConBase2YAltura1TieneArea2() {
		Punto esqInfIzq = new Punto(1, 1);
		Rectangulo rec = new Rectangulo(esqInfIzq, 2, 1);

		Assert.assertEquals(2, rec.calcularArea(), 0.001);

	}

	@Test
	public void crearUnRectanguloEn1_1ConBase2YAltura1TieneEsquinaDerechaEn3_2() {
		Punto esqInfIzq = new Punto(1, 1);
		Rectangulo rec = new Rectangulo(esqInfIzq, 2, 1);

		Assert.assertEquals(3, rec.getEsquinaSupDer().getEjeX(), 0.001);
		Assert.assertEquals(2, rec.getEsquinaSupDer().getEjeY(), 0.001);
	}

	@Test
	public void mover3_1UnRectanguloEn1_1LoLlevaA_3_1() {
		Punto EsqInfIzq = new Punto(1, 1);
		Rectangulo rec = new Rectangulo(EsqInfIzq, 2, 1);

		rec.mover(3, 1);

		Assert.assertEquals(4, rec.getPosicion().getEjeX(), 0.001);
		Assert.assertEquals(2, rec.getPosicion().getEjeY(), 0.001);
	}

	@Test
	public void mover3_1UnRectanguloEn1_1ConBase2YAltura1ColocaLaEsqSupDerEn_6_3() {
		Punto EsqInfIzq = new Punto(1, 1);
		Rectangulo rec = new Rectangulo(EsqInfIzq, 2, 1);

		rec.mover(3, 1);

		Assert.assertEquals(6, rec.getEsquinaSupDer().getEjeX(), 0.001);
		Assert.assertEquals(3, rec.getEsquinaSupDer().getEjeY(), 0.001);
	}

	@Test
	public void crearUnCiculoEn1_1ConRadio2TieneArea12_566() {
		Punto centro = new Punto(1, 1);
		Circulo cir = new Circulo(centro, 2);

		Assert.assertEquals(12.566, cir.calcularArea(), 0.001);
	}

	@Test
	public void mover3_1UnCirculoEn1_1conRadio2LoLlevaA4_2rr() {
		Punto centro = new Punto(1, 1);
		Circulo cir = new Circulo(centro, 2);

		cir.mover(3, 1);

		Assert.assertEquals(4, cir.getPosicion().getEjeX(), 0.001);
		Assert.assertEquals(2, cir.getPosicion().getEjeY(), 0.001);
	}

	@Test
	public void crearUnCuadradoEn1_1ConLado2TieneArea4() {
		Punto esqInfIzq = new Punto(1, 1);
		Cuadrado cua = new Cuadrado(esqInfIzq, 2);

		Assert.assertEquals(4, cua.calcularArea(), 0.001);

	}

	@Test
	public void crearUnCuadradoEn1_1ConLado2TieneEsquinaDerechaEn3_3() {
		Punto esqInfIzq = new Punto(1, 1);
		Cuadrado cua = new Cuadrado(esqInfIzq, 2);

		Assert.assertEquals(3, cua.getEsquinaSupDer().getEjeX(), 0.001);
		Assert.assertEquals(3, cua.getEsquinaSupDer().getEjeY(), 0.001);
	}

	@Test
	public void mover3_1UnCuadradoEn1_1LoLlevaA_3_1() {
		Punto esqInfIzq = new Punto(1, 1);
		Cuadrado cua = new Cuadrado(esqInfIzq, 2);

		cua.mover(3, 1);

		Assert.assertEquals(4, cua.getPosicion().getEjeX(), 0.001);
		Assert.assertEquals(2, cua.getPosicion().getEjeY(), 0.001);
	}

	@Test
	public void mover3_1UnCuadradoEn1_1ConLado2ColocaEsqSupDerEn_6_4() {
		Punto esqInfIzq = new Punto(1, 1);
		Cuadrado cua = new Cuadrado(esqInfIzq, 2);

		cua.mover(3, 1);

		Assert.assertEquals(6, cua.getEsquinaSupDer().getEjeX(), 0.001);
		Assert.assertEquals(4, cua.getEsquinaSupDer().getEjeY(), 0.001);
	}

}
