package ar.edu.unlam.pb2.exceptions;

public class NumeroDeTarjetaInvalidoException extends Exception {
	public NumeroDeTarjetaInvalidoException(String errorMsg) {
		super(errorMsg);
	}
}
