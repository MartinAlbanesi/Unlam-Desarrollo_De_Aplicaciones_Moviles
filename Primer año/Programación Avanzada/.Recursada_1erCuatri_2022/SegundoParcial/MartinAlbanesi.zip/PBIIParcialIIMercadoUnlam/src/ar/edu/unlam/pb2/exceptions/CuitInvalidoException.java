package ar.edu.unlam.pb2.exceptions;

public class CuitInvalidoException extends Exception {
	public CuitInvalidoException(String errorMsg) {
		super(errorMsg);
	}
}
