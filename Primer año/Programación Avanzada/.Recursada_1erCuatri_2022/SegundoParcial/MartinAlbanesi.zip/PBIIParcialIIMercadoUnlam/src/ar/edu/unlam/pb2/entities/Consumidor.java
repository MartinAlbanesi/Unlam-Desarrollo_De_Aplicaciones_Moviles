package ar.edu.unlam.pb2.entities;

import java.util.HashSet;
import java.util.Objects;

import ar.edu.unlam.pb2.interfaces.Pagadora;

public class Consumidor implements Comparable<Consumidor>{
	private Integer dni;
	private String nombre;
	private HashSet<MedioDePago> mediosDePago;
	
	public Consumidor(Integer dni, String nombre) {
		super();
		this.dni = dni;
		this.nombre = nombre;
		this.mediosDePago = new HashSet<MedioDePago>();
	}

	public Integer getDni() {
		return dni;
	}

	public void setDni(Integer dni) {
		this.dni = dni;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public HashSet<MedioDePago> getMediosDePago() {
		return mediosDePago;
	}

	public void setMediosDePago(HashSet<MedioDePago> mediosDePago) {
		this.mediosDePago = mediosDePago;
	}

	@Override
	public int hashCode() {
		return Objects.hash(dni);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Consumidor other = (Consumidor) obj;
		return Objects.equals(dni, other.dni);
	}

	@Override
	public int compareTo(Consumidor o) {
		if(this.getDni().equals(o.getDni())) {
			return 1;
		}
		return 0;
	}

	public void agregarMedioDePago(MedioDePago tarjetaDeDebito) {
		mediosDePago.add(tarjetaDeDebito);
		
	}

	public MedioDePago getMedioDePago(Long numero) throws Exception {
		for(MedioDePago medioDePagoActual: mediosDePago) {
			if(medioDePagoActual instanceof TarjetaDeCredito ) 
				
				if(((TarjetaDeCredito) medioDePagoActual).getNumero().equals(numero))
					return medioDePagoActual;
					
			if(medioDePagoActual instanceof TarjetaDeDebito ) 
				if(((TarjetaDeDebito) medioDePagoActual).getNumero().equals(numero))
					return medioDePagoActual;
			}
		throw new Exception("No se encontro el medio de pago");
	}
	
	
	
}
