package ar.edu.unlam.pb2.interfaces;

import ar.edu.unlam.pb2.exceptions.SaldoInsuficienteException;

public interface Transferible {
	void depositar(Double valor);
	void extraer(Double valor) throws SaldoInsuficienteException;
}
