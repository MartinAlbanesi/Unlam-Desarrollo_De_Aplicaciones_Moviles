package ar.edu.unlam.pb2.entities;

public class Compra {
	private Comercio comercio;
	private Double precio;
	
	public Compra(Comercio comercio, Double precio) {
		super();
		this.comercio = comercio;
		this.precio = precio;
	}

	public Comercio getComercio() {
		return comercio;
	}

	public void setComercio(Comercio comercio) {
		this.comercio = comercio;
	}

	public Double getPrecio() {
		return precio;
	}

	public void setPrecio(Double precio) {
		this.precio = precio;
	}
	
}
