package ar.edu.unlam.pb2.entities;

public class MedioDePago {
	private String titular;

	public MedioDePago(String titular) {
		super();
		this.titular = titular;
	}

	public String getTitular() {
		return titular;
	}

	public void setTitular(String titular) {
		this.titular = titular;
	}
	
	
}
