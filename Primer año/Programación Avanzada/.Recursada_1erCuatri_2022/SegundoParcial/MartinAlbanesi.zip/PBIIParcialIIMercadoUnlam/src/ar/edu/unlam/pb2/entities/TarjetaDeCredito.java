package ar.edu.unlam.pb2.entities;

import ar.edu.unlam.pb2.exceptions.NumeroDeTarjetaInvalidoException;
import ar.edu.unlam.pb2.interfaces.Pagadora;

public class TarjetaDeCredito extends MedioDePago implements Pagadora {

	private Long numero;
	private String fechaDeVencimiento;
	private Integer codigoDeSeguridad;
	private Double consumo;
	private Double limiteDeCompraEnPesos;
	private Double limiteDeCompraEnDolares;
	
	public TarjetaDeCredito(Long numero, String titular, String fechaDeVencimiento, Integer codigoDeSeguridad,
			Double limiteDeCompraEnPesos, Double limiteDeCompraEnDolares) throws NumeroDeTarjetaInvalidoException {
		super(titular);
		if(Long.toString(numero).length()==16) {
			this.numero = numero;
		}else {
			throw new NumeroDeTarjetaInvalidoException("Numero de tarjeta invalido");
		}
		this.fechaDeVencimiento = fechaDeVencimiento;
		this.codigoDeSeguridad = codigoDeSeguridad;
		this.limiteDeCompraEnPesos = limiteDeCompraEnPesos;
		this.limiteDeCompraEnDolares = limiteDeCompraEnDolares;
	}

	public Long getNumero() {
		return numero;
	}

	public void setNumero(Long numero) {
		this.numero = numero;
	}

	public String getFechaDeVencimiento() {
		return fechaDeVencimiento;
	}

	public void setFechaDeVencimiento(String fechaDeVencimiento) {
		this.fechaDeVencimiento = fechaDeVencimiento;
	}

	public Integer getCodigoDeSeguridad() {
		return codigoDeSeguridad;
	}

	public void setCodigoDeSeguridad(Integer codigoDeSeguridad) {
		this.codigoDeSeguridad = codigoDeSeguridad;
	}

	public Double getLimiteDeCompraEnPesos() {
		return limiteDeCompraEnPesos;
	}

	public void setLimiteDeCompraEnPesos(Double limiteDeCompraEnPesos) {
		this.limiteDeCompraEnPesos = limiteDeCompraEnPesos;
	}

	public Double getLimiteDeCompraEnDolares() {
		return limiteDeCompraEnDolares;
	}

	public void setLimiteDeCompraEnDolares(Double limiteDeCompraEnDolares) {
		this.limiteDeCompraEnDolares = limiteDeCompraEnDolares;
	}

	@Override
	public Double getSaldo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setSaldo(Double d) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void pagar(Double monto) throws Exception {
		if(monto < this.limiteDeCompraEnPesos) {
			consumo+= monto;
		}else {
			throw new Exception("El monto es mayor al limite");
		}
	}
	

}
