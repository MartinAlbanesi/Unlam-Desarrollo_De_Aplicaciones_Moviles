package ar.edu.unlam.pb2.entities;

import java.util.HashSet;


public class Billetera {
	private String nombre;
	private HashSet<Comercio> comercios;
	private HashSet<Consumidor> consumidores;
	private HashSet<Compra> compras;
	
	public Billetera(String nombre) {
		super();
		this.nombre = nombre;
		this.comercios = new HashSet<Comercio>();
		this.consumidores = new HashSet<Consumidor>();
		this.compras = new HashSet<Compra>();
		
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void agregarComercio(Comercio comercio) {
				comercios.add(comercio);
	}
	
	public int getCantidadDeComercios() {
		return comercios.size();
	}
	
	public void agregarConsumidor(Consumidor consumidor) {
		consumidores.add(consumidor);
	}
	
	public int getCantidadDeConsumidores() {
		return consumidores.size();
	}

	public void agregarMedioDePago(Integer dni, MedioDePago tarjetaDeDebito) {
		Consumidor buscado = buscarConsumidor(dni);
		buscado.agregarMedioDePago(tarjetaDeDebito);
	}
	
	public int getCantidadDeMediosDePago(Integer dni) {
		Consumidor buscado = buscarConsumidor(dni);
		return buscado.getMediosDePago().size();
	}
	
	public Consumidor buscarConsumidor(Integer dni) {
		for(Consumidor consumidor: consumidores) {
			if(consumidor.getDni().equals(dni)) {
				return consumidor;
			}
		}
		return null;
	}

	
	public Compra generarCodigoQr(Long cuit, Double precio) {
		Comercio buscado = buscarComercio(cuit);
		return new Compra(buscado,precio);
	}
	
	public Comercio buscarComercio(Long cuit) {
		for(Comercio comercio: comercios) {
			if(comercio.getCuit().equals(cuit)) {
				return comercio;
			}
		}
		return null;
	}

	public Boolean pagar(Compra codigoQR, MedioDePago medioDePago) throws Exception {
		compras.add(codigoQR);
		if(medioDePago instanceof TarjetaDeCredito ) {
			((TarjetaDeCredito)medioDePago).pagar(codigoQR.getPrecio());
		}
		if(medioDePago instanceof TarjetaDeDebito ) {
			((TarjetaDeCredito)medioDePago).pagar(codigoQR.getPrecio());
		}
	return true;
	}
}
