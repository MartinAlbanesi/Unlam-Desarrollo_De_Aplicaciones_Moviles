package ar.edu.unlam.pb2.exceptions;

public class SaldoInsuficienteException extends Exception {
	public SaldoInsuficienteException(String msg) {
	super(msg);
	}
}
