package ar.edu.unlam.pb2.exceptions;

public class ExcedeLimiteDeCompraException extends Exception {
	public ExcedeLimiteDeCompraException(String errorMsg) {
		super(errorMsg);
	}
}
