package ar.edu.unlam.pb2.exceptions;

public class CVUInvalidoException extends Exception {
	public CVUInvalidoException(String errorMsg) {
		super(errorMsg);
	}
}
