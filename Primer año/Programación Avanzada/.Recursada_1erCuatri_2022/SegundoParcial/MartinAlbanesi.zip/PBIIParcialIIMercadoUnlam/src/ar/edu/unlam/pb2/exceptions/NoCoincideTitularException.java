package ar.edu.unlam.pb2.exceptions;

public class NoCoincideTitularException extends Exception {
	public NoCoincideTitularException(String errorMsg) {
		super(errorMsg);
	}
}
