package ar.edu.unlam.pb2.entities;

import ar.edu.unlam.pb2.exceptions.SaldoInsuficienteException;
import ar.edu.unlam.pb2.interfaces.Transferible;

public class CuentaBancaria extends MedioDePago implements Transferible {
	private String cbu;
	private String entidad;
	private Double saldo;
	
	public CuentaBancaria(String cbu, String entidad, String titular) {
		super(titular);
		this.cbu = cbu;
		this.entidad = entidad;
	}

	public String getCbu() {
		return cbu;
	}

	public void setCbu(String cbu) {
		this.cbu = cbu;
	}

	public String getEntidad() {
		return entidad;
	}

	public void setEntidad(String entidad) {
		this.entidad = entidad;
	}

	@Override
	public void depositar(Double valor) {
		saldo += valor;
	}

	@Override
	public void extraer(Double valor) throws SaldoInsuficienteException{
		if(valor < this.saldo) {
			saldo -= valor;
		}else {
			//throw new SaldoInsuficienteException("No se puede extraer el monto, saldo insuficiente");
		}
		
	}
	

}
