package ar.edu.unlam.pb2.entities;

import java.util.Objects;

import ar.edu.unlam.pb2.exceptions.NumeroDeTarjetaInvalidoException;
import ar.edu.unlam.pb2.interfaces.Pagadora;

public class TarjetaDeDebito extends MedioDePago implements Pagadora, Comparable<TarjetaDeDebito>{

	private Long numero;
	private Integer codigoDeSeguridad;
	private String fechaDeVencimiento;
	private Double saldo;
	
	
	public TarjetaDeDebito(Long numero, String titular, String fechaDeVencimiento,Integer codigoDeSeguridad) throws NumeroDeTarjetaInvalidoException {
		super(titular);
		if(Long.toString(numero).length()==16) {
			this.numero = numero;
		}else {
			throw new NumeroDeTarjetaInvalidoException("Numero de tarjeta invalido");
		}
		this.codigoDeSeguridad = codigoDeSeguridad;
		this.fechaDeVencimiento = fechaDeVencimiento;
	}
	

	public Long getNumero() {
		return numero;
	}

	public Integer getCodigoDeSeguridad() {
		return codigoDeSeguridad;
	}

	public String getFechaDeVencimiento() {
		return fechaDeVencimiento;
	}

	@Override
	public Double getSaldo() {
		return saldo;
	}

	@Override
	public void setSaldo(Double saldo) {
		this.saldo = saldo;
	}

	
	
	@Override
	public int hashCode() {
		return Objects.hash(numero);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TarjetaDeDebito other = (TarjetaDeDebito) obj;
		return Objects.equals(numero, other.numero);
	}


	@Override
	public int compareTo(TarjetaDeDebito o) {
		if(this.getNumero().equals(o.getNumero())) {
			return 1;
		}
		return 0;
	}


	@Override
	public void pagar(Double monto) throws Exception {
		if(monto < this.saldo) {
			this.saldo =- monto;
		}else {
			throw new Exception("El monto es mayor al saldo disponible");
		}
	}
	
	
	
	
	
}
