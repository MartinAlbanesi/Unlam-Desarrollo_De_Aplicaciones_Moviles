package ar.edu.unlam.pb2.entities;

import ar.edu.unlam.pb2.interfaces.Transferible;

public class CuentaVirtual extends MedioDePago implements Transferible {
	private String cvu;
	private String entidad;
	private Double saldo;
	
	public CuentaVirtual(String cvu, String entidad, String titular) {
		super(titular);
		this.cvu = cvu;
		this.entidad = entidad;
	}

	public String getCvu() {
		return cvu;
	}

	public void setCvu(String cbu) {
		this.cvu = cbu;
	}

	public String getEntidad() {
		return entidad;
	}

	public void setEntidad(String entidad) {
		this.entidad = entidad;
	}

	@Override
	public void depositar(Double valor) {
		saldo += valor;
	}

	@Override
	public void extraer(Double valor) {
		saldo -= valor;
	}
	
}
