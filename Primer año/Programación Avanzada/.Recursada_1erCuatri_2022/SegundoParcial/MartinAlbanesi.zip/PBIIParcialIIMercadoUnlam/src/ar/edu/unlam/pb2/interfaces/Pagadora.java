package ar.edu.unlam.pb2.interfaces;

public interface Pagadora {

	Double getSaldo();
	void setSaldo(Double d);
	void pagar(Double monto) throws Exception;
}
