package ar.edu.unlam.pb2.exceptions;

public class CBUInvalidoException extends Exception {
	public CBUInvalidoException(String errorMsg) {
		super(errorMsg);
	}
}
