package ar.edu.unlam.ae;

public class PasajeroVip extends Pasajero {

	public PasajeroVip(Integer dni) {
		super(dni);
		// TODO Auto-generated constructor stub
	}

}
