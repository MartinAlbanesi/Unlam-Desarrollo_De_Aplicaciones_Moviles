package ar.edu.unlam.pb2;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestVeterinaria {

	@Test
	public void queSePuedaInstanciarUnaVeterinariaConNombre() {
	}

	@Test
	public void queSePuedaCrearUnDuenioConDniYConNombre() {}
	
	@Test
	public void queSePuedaCrearUnaMascotaConNombreIdApodoYTipoDeMascota() {
		// El tipo de mascota puede ser solamente doméstica y exótica (enum)
	}
	
	@Test
	public void queSePuedaAgregarDosMascotasAUnDuenio() {
		
	}
	
	@Test
	public void queAlAgregarDosMascotasConMismoIdParaUnMismoDuenioLanceUnaExcepcionMascotaDuplicadaException() {
	}
	
	@Test
	public void queSePuedaCrearUnMedicamentoConIdDescripcionYPrecio() {
		
	}
	
	@Test
	public void queSePuedanAgregarDueniosDeMascotasAUnaVeterinaria() {
		
	}
	
	@Test
	public void queSePuedaCrearUnaAtencionConIdDeDuenioIdDeMascotaYPrecio() throws DuenioInexistenteException, MascotaNoEncontradaException{
		
	}
	
	@Test
	public void queSePuedaAsignarVariosMedicamentosAUnaAtencion() {
		// Para asignar un medicamento necesita el id de la atencion y el id del medicamento
	}
	
	@Test
	public void queSePuedaCalcularElPrecioTotalDeUnaAtencion() {
		// El precio total de la atencion será la suma del precio de la atencion mas la suma del precio de todos los medicamentos
	}
	
	@Test
	public void queSePuedaObtenerDeUnDuenioUnaListaDeMascotasDomesticasOrdenadasPorApodo() {
		
	}
	
	@Test
	public void queSePuedaObtenerUnMapaConIdDeAtencionYIdDeMascota() {
		
	}
	
}
