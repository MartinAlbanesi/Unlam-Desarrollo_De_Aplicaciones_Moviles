package ar.edu.unlam.pb2.eva03.enumeradores;

public enum TipoDeBicicleta {
	RUTA,
	MOUNTAIN,
	BMX,
	TRIA
}
