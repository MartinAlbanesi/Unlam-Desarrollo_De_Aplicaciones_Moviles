package ar.edu.unlam.pb2.eva03.interfaces;

public interface INadador {

}
