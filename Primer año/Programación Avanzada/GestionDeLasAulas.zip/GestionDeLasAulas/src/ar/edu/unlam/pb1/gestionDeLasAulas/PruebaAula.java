package ar.edu.unlam.pb1.gestionDeLasAulas;

public class PruebaAula {

	public static void main(String[] args) {

		Aula laboratorio01 = new Aula(1, 15, 6);
		
		laboratorio01.sentarUnAlumno(14, 2, "Sofia");
		laboratorio01.sentarUnAlumno(0, 1, "Brian");
		laboratorio01.sentarUnAlumno(0, 3, "Natalia");
		laboratorio01.sentarUnAlumno(0, 2, "Bruno");
		laboratorio01.sentarUnAlumno(9, 2, "Mat�as");
		
		System.out.println(laboratorio01);
	}

}
