package ar.edu.unlam.pb1.gestionDeLasAulas;

public class Aula {

	private int numero;
	private String bancos[][];
	private final int CANTIDAD_DE_COLUMNAS;
	private final int CANTIDAD_DE_FILAS;
	
	public Aula(int numero, int cantidadDeFilas, int cantidadDeColumnas) {
		this.numero = numero;
		this.bancos = new String[cantidadDeFilas][cantidadDeColumnas];
		this.CANTIDAD_DE_FILAS = cantidadDeFilas;
		this.CANTIDAD_DE_COLUMNAS = cantidadDeColumnas;
	}
	
	public void sentarUnAlumno(int fila, int columna, String nombre) {
		bancos[fila][columna] = nombre;
	}
	
	public String toString() {
		String mapa = "";
		
		for(int i=0; i<bancos.length; i++) {
			mapa += " | ";
			for(int j=0; j<bancos[9].length; j++) {
				if(bancos[i][j] == null) {
					mapa += "\t| ";
				}
				else {
					mapa += bancos[i][j].substring(0, 5) + "\t| ";
				}
			}
			mapa += " \n";
		}
		return mapa;
	}
}
