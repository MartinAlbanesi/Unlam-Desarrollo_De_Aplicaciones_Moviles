package ar.com.develup.tateti

import android.app.Application

class TaTeTiApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // TODO-07-NOTIFICATION
        // Suscribirse al topic "general"
    }
}