package ar.com.develup.tateti.modelo

object Constantes {
    const val TABLA_PARTIDAS = "PARTIDAS"
    const val EXTRA_PARTIDA = "EXTRA_PARTIDA"
}