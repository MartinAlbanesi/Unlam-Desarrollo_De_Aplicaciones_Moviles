package ar.com.develup.tateti.modelo

import java.io.Serializable

data class Movimiento(val posicion: Int = 0, val jugador: String = "") : Serializable